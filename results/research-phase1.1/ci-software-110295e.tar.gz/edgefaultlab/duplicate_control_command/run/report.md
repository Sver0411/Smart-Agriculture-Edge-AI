# EdgeFaultLab Run

Scenario: smart agriculture - duplicate control command
Seed: 42
Duration: 12s
Result: PASS

## Faults

- 2.005s `FAULT_ACTIVATED` nodes_to_gateway_a1 fault=duplicate-command
- 2.214s `MESSAGE_DUPLICATED` nodes_to_gateway_a1 94ed516c4cbf fault=duplicate-command copies=1
- 2.615s `MESSAGE_DUPLICATED` nodes_to_gateway_a1 9013fcde3b4d fault=duplicate-command copies=1
- 3.217s `MESSAGE_DUPLICATED` nodes_to_gateway_a1 fab0f3417882 fault=duplicate-command copies=1
- 12.004s `PROCESS_EXIT` server pid=3219 exit=-15
- 12.005s `PROCESS_EXIT` gateway_a1 pid=3220 exit=-15
- 12.007s `PROCESS_EXIT` gateway_a2 pid=3221 exit=-15
- 12.008s `PROCESS_EXIT` sensor_b1 pid=3222 exit=-15
- 12.009s `PROCESS_EXIT` controller_c1 pid=3223 exit=-15
- 12.010s `PROCESS_EXIT` sensor_b2 pid=3224 exit=-15
- 12.011s `PROCESS_EXIT` controller_c2 pid=3225 exit=-15

## Messages

- messages received: 1075
- messages forwarded: 1078
- messages dropped: 0
- messages delayed: 0
- messages duplicated: 3
- messages reordered: 0
- messages mutated: 0
- malformed messages: 0
- messages too large: 0
- messages matched: 3

## Processes

- server: pid=3219 running=False restarts=0
- gateway_a1: pid=3220 running=False restarts=0
- gateway_a2: pid=3221 running=False restarts=0
- sensor_b1: pid=3222 running=False restarts=0
- controller_c1: pid=3223 running=False restarts=0
- sensor_b2: pid=3224 running=False restarts=0
- controller_c2: pid=3225 running=False restarts=0

## Recovery

Recovery time: n/a (no disruptive fault took effect, or nothing recovered)

## Assertions

PASS a command_id is executed at most once - 19 distinct payload.command_id value(s) in 19 matching message(s)
PASS commands still run at all - observed 19 message(s) matching [payload.status='EXECUTED', type='CONTROL_RESULT']
PASS no unsafe execution was reported - no message matching [payload.reason='UNSAFE_EXECUTION', type='CONTROL_RESULT'] was ever delivered

## Result

PASS
