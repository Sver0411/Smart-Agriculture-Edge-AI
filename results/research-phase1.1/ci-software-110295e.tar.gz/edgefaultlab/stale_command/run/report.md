# EdgeFaultLab Run

Scenario: smart agriculture - stale command
Seed: 42
Duration: 12s
Result: PASS

## Faults

- 0.138s `FAULT_ACTIVATED` nodes_to_gateway_a1 fault=age-commands
- 0.425s `MESSAGE_MUTATED` nodes_to_gateway_a1 da9288b04733 fault=age-commands timestamp 1791457389.6007576 -> 1791457359.6007576
- 0.828s `MESSAGE_MUTATED` nodes_to_gateway_a1 52b36604f0ec fault=age-commands timestamp 1791457390.0029404 -> 1791457360.0029404
- 1.229s `MESSAGE_MUTATED` nodes_to_gateway_a1 4dd0eeb5a78e fault=age-commands timestamp 1791457390.404292 -> 1791457360.404292
- 1.630s `MESSAGE_MUTATED` nodes_to_gateway_a1 01e5c7507d7b fault=age-commands timestamp 1791457390.8055542 -> 1791457360.8055542
- 2.032s `MESSAGE_MUTATED` nodes_to_gateway_a1 61f024a4595c fault=age-commands timestamp 1791457391.2073607 -> 1791457361.2073607
- 2.433s `MESSAGE_MUTATED` nodes_to_gateway_a1 87c84f35cbb6 fault=age-commands timestamp 1791457391.6087084 -> 1791457361.6087084
- 3.036s `MESSAGE_MUTATED` nodes_to_gateway_a1 6eab61c979d9 fault=age-commands timestamp 1791457392.2111292 -> 1791457362.2111292
- 3.437s `MESSAGE_MUTATED` nodes_to_gateway_a1 0712d8b09559 fault=age-commands timestamp 1791457392.6124482 -> 1791457362.6124482
- 4.241s `MESSAGE_MUTATED` nodes_to_gateway_a1 2e25af1fade4 fault=age-commands timestamp 1791457393.4157763 -> 1791457363.4157763
- 4.642s `MESSAGE_MUTATED` nodes_to_gateway_a1 33bd04fc274f fault=age-commands timestamp 1791457393.8174949 -> 1791457363.8174949
- 5.044s `MESSAGE_MUTATED` nodes_to_gateway_a1 9e11e90c00f7 fault=age-commands timestamp 1791457394.2191978 -> 1791457364.2191978
- 5.647s `MESSAGE_MUTATED` nodes_to_gateway_a1 2d0e1063b4f8 fault=age-commands timestamp 1791457394.8220537 -> 1791457364.8220537
- 7.053s `MESSAGE_MUTATED` nodes_to_gateway_a1 5ac6d9591cfd fault=age-commands timestamp 1791457396.2284122 -> 1791457366.2284122
- 8.259s `MESSAGE_MUTATED` nodes_to_gateway_a1 ad4c6ef42ae0 fault=age-commands timestamp 1791457397.4344435 -> 1791457367.4344435
- 8.661s `MESSAGE_MUTATED` nodes_to_gateway_a1 2ed064008838 fault=age-commands timestamp 1791457397.8365257 -> 1791457367.8365257
- 9.465s `MESSAGE_MUTATED` nodes_to_gateway_a1 76389a868375 fault=age-commands timestamp 1791457398.640134 -> 1791457368.640134
- 10.670s `MESSAGE_MUTATED` nodes_to_gateway_a1 0931df5a180d fault=age-commands timestamp 1791457399.8455229 -> 1791457369.8455229
- 11.474s `MESSAGE_MUTATED` nodes_to_gateway_a1 997f5eba2265 fault=age-commands timestamp 1791457400.6493897 -> 1791457370.6493897
- 11.876s `MESSAGE_MUTATED` nodes_to_gateway_a1 19981b96f54d fault=age-commands timestamp 1791457401.050915 -> 1791457371.050915
- 12.004s `PROCESS_EXIT` server pid=3227 exit=-15
- 12.005s `PROCESS_EXIT` gateway_a1 pid=3228 exit=-15
- 12.007s `PROCESS_EXIT` gateway_a2 pid=3229 exit=-15
- 12.008s `PROCESS_EXIT` sensor_b1 pid=3230 exit=-15
- 12.009s `PROCESS_EXIT` controller_c1 pid=3231 exit=-15
- 12.010s `PROCESS_EXIT` sensor_b2 pid=3232 exit=-15
- 12.011s `PROCESS_EXIT` controller_c2 pid=3233 exit=-15

## Messages

- messages received: 1071
- messages forwarded: 1071
- messages dropped: 0
- messages delayed: 0
- messages duplicated: 0
- messages reordered: 0
- messages mutated: 19
- malformed messages: 0
- messages too large: 0
- messages matched: 19

## Processes

- server: pid=3227 running=False restarts=0
- gateway_a1: pid=3228 running=False restarts=0
- gateway_a2: pid=3229 running=False restarts=0
- sensor_b1: pid=3230 running=False restarts=0
- controller_c1: pid=3231 running=False restarts=0
- sensor_b2: pid=3232 running=False restarts=0
- controller_c2: pid=3233 running=False restarts=0

## Recovery

Recovery time: n/a (no disruptive fault took effect, or nothing recovered)

## Assertions

PASS no aged command was executed - no message matching [payload.status='EXECUTED', type='CONTROL_RESULT'] was ever delivered
PASS the controller refused the aged command - observed 19 message(s) matching [payload.status='REJECTED', type='CONTROL_RESULT']
PASS the refusal was clean, not a safety violation - no message matching [payload.reason='UNSAFE_EXECUTION', type='CONTROL_RESULT'] was ever delivered

## Result

PASS
